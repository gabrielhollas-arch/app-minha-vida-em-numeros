import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  ActivityIndicator,
  Platform,
  TouchableOpacity,
  Alert,
} from 'react-native';

import * as FileSystem from 'expo-file-system'; // correto
// NÃO faça: import * as Sharing from 'expo-sharing.js' ❌
// Usaremos import dinâmico para expo-sharing quando necessário

import * as Database from './services/Database';
import Formulario from './components/Formulario';
import ListaRegistros from './components/ListaRegistros';
import Grafico from './components/Grafico';

export default function App() {
  const [registros, setRegistros] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [ordenacao, setOrdenacao] = useState('recentes'); // 'recentes' | 'maior_corridas'

  useEffect(() => {
    const init = async () => {
      const dados = await Database.carregarDados();
      setRegistros(Array.isArray(dados) ? dados : []);
      setCarregando(false);
    };
    init();
  }, []);

  useEffect(() => {
    if (!carregando) {
      Database.salvarDados(registros);
    }
  }, [registros, carregando]);

  const handleSave = (corridas, recebidas, tds) => {
    const toNumber = (v) => parseFloat(String(v).replace(',', '.'));
    const corridasNum = toNumber(corridas);
    const recebidasNum = toNumber(recebidas);
    const tdsNum = toNumber(tds);

    if ([corridasNum, recebidasNum, tdsNum].some((n) => Number.isNaN(n))) {
      return Alert.alert('Atenção', 'Preencha números válidos para corridas, recebidas e TDs.');
    }
    if (corridasNum < 0 || recebidasNum < 0 || tdsNum < 0) {
      return Alert.alert('Erro de Validação', 'Nenhum valor pode ser negativo.');
    }
    if (corridasNum > 600) return Alert.alert('Validação', 'Jardas corridas muito altas para um dia.');
    if (recebidasNum > 600) return Alert.alert('Validação', 'Jardas recebidas muito altas para um dia.');
    if (tdsNum > 10) return Alert.alert('Validação', 'TDs muito altos para um dia.');

    if (editingId !== null) {
      setRegistros((prev) =>
        prev.map((reg) =>
          reg.id === editingId
            ? { ...reg, corridas: corridasNum, recebidas: recebidasNum, tds: tdsNum }
            : reg
        )
      );
    } else {
      const novoRegistro = {
        id: Date.now(),
        data: new Date().toLocaleDateString('pt-BR'),
        corridas: corridasNum,
        recebidas: recebidasNum,
        tds: tdsNum,
      };
      setRegistros((prev) => [...prev, novoRegistro]);
    }

    setEditingId(null);
    Alert.alert('Sucesso!', 'Seu registro foi salvo!');
  };

  const handleDelete = (id) => {
    setRegistros((prev) => prev.filter((reg) => reg.id !== id));
    if (editingId === id) setEditingId(null);
    Alert.alert('Sucesso!', 'O registro foi deletado.');
  };

  const handleEdit = (registro) => setEditingId(registro.id);
  const handleCancel = () => setEditingId(null);

  const exportarDados = async () => {
    try {
      if (Platform.OS === 'web') {
        if (registros.length === 0) return Alert.alert('Aviso', 'Nenhum dado para exportar.');
        const jsonString = JSON.stringify(registros, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'dados.json';
        a.click();
        URL.revokeObjectURL(url);
        return;
      }

      // Mobile (Expo Go)
      const fileInfo = await FileSystem.getInfoAsync(Database.fileUri);
      if (!fileInfo.exists) {
        if (registros.length === 0) return Alert.alert('Aviso', 'Nenhum dado para exportar.');
        await FileSystem.writeAsStringAsync(
          Database.fileUri,
          JSON.stringify(registros, null, 2),
          { encoding: 'utf8' }
        );
      }

      // Importa expo-sharing dinamicamente só quando necessário
      let Sharing;
      try {
        Sharing = await import('expo-sharing'); // correto
      } catch (e) {
        return Alert.alert('Dependência faltando', 'Adicione "expo-sharing" nas dependências do Snack.');
      }

      const canShare = await Sharing.isAvailableAsync();
      if (!canShare) return Alert.alert('Erro', 'Compartilhamento não disponível neste dispositivo.');
      await Sharing.shareAsync(Database.fileUri);
    } catch (e) {
      console.error('Erro ao exportar dados:', e);
      Alert.alert('Erro', 'Falha ao exportar o arquivo.');
    }
  };

  // Ordenação para exibição
  let registrosExibidos = [...registros];
  if (ordenacao === 'maior_corridas') {
    registrosExibidos.sort((a, b) => (b.corridas ?? 0) - (a.corridas ?? 0));
  } else {
    registrosExibidos.sort((a, b) => b.id - a.id); // mais recentes primeiro
  }

  if (carregando) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#3498db" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <Text style={styles.titulo}>Meu Diário de Futebol Americano 🏈</Text>

        {/* Visualização: gráfico + filtros */}
        <View style={styles.card}>
          <Text style={styles.subtitulo}>Visualizar</Text>

          <Grafico
            registros={registrosExibidos}
            campo="corridas"
            titulo="Evolução — Jardas Corridas"
            sufixoYAxis=" yd"
          />

          <View style={{ flexDirection: 'row', justifyContent: 'space-evenly', marginTop: 10 }}>
            <TouchableOpacity
              style={[styles.botaoExportar, { backgroundColor: ordenacao === 'recentes' ? '#3498db' : '#95a5a6' }]}
              onPress={() => setOrdenacao('recentes')}
            >
              <Text style={styles.botaoTexto}>Mais Recentes</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.botaoExportar, { backgroundColor: ordenacao === 'maior_corridas' ? '#3498db' : '#95a5a6' }]}
              onPress={() => setOrdenacao('maior_corridas')}
            >
              <Text style={styles.botaoTexto}>Maior (Jardas Corridas)</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Formulário */}
        <Formulario
          onSave={handleSave}
          onCancel={handleCancel}
          registroEmEdicao={registros.find((r) => r.id === editingId) || null}
        />

        {/* Lista */}
        <ListaRegistros
          registros={registrosExibidos}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />

        {/* Exportar "banco de dados" */}
        <View style={styles.card}>
          <Text style={styles.subtitulo}>Exportar "Banco de Dados"</Text>
          <TouchableOpacity style={styles.botaoExportar} onPress={exportarDados}>
            <Text style={styles.botaoTexto}>Exportar arquivo dados.json</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: Platform.OS === 'android' ? 25 : 0, backgroundColor: '#f0f4f7' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  titulo: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginVertical: 20, color: '#1e3a5f' },
  card: { backgroundColor: 'white', borderRadius: 8, padding: 15, marginHorizontal: 15, marginBottom: 20, elevation: 3 },
  subtitulo: { fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#34495e' },
  botaoExportar: { backgroundColor: '#27ae60', padding: 15, borderRadius: 5, alignItems: 'center', marginTop: 5, minWidth: 150 },
  botaoTexto: { color: 'white', fontSize: 16, fontWeight: 'bold', textAlign: 'center' },
});