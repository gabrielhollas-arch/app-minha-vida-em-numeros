import React, { useMemo } from 'react';
import { View, Text, Dimensions } from 'react-native';
import { LineChart } from 'react-native-chart-kit';

export default function Grafico({
  registros,
  campo = 'corridas',
  titulo = 'Evolução — Jardas Corridas',
  sufixoYAxis = ' yd',
}) {
  const ordenados = useMemo(() => [...registros].sort((a, b) => a.id - b.id), [registros]);

  if (ordenados.length < 2) {
    return (
      <Text style={{ textAlign: 'center', marginVertical: 8 }}>
        Adicione pelo menos 2 registros para ver o gráfico.
      </Text>
    );
  }

  const ultimos = ordenados.slice(-12);
  const labels = ultimos.map((reg) =>
    new Date(reg.id).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })
  );
  const valores = ultimos.map((reg) => Number(reg[campo] ?? 0));

  const data = { labels, datasets: [{ data: valores }] };

  return (
    <View>
      <Text style={{ textAlign: 'center', fontWeight: 'bold', fontSize: 16, marginBottom: 6 }}>
        {titulo}
      </Text>
      <LineChart
        data={data}
        width={Dimensions.get('window').width - 40}
        height={220}
        fromZero
        yAxisSuffix={sufixoYAxis}
        chartConfig={{
          backgroundColor: '#0a84ff',
          backgroundGradientFrom: '#1e90ff',
          backgroundGradientTo: '#63a4ff',
          decimalPlaces: 0,
          color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
          labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
          style: { borderRadius: 16 },
          propsForDots: { r: '4', strokeWidth: '2', stroke: '#63a4ff' },
        }}
        bezier
        style={{ marginVertical: 8, borderRadius: 16 }}
      />
    </View>
  );
}